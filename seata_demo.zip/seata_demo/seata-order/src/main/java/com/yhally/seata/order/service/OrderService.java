package com.yhally.seata.order.service;

import com.yhally.seata.order.domain.Order;

public interface OrderService {

    void create(Order order);

}
